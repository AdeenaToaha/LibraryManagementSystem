// **************************************************************************************************
//		CMessageDetailsIC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;


namespace Library_Management_System.Som
{
  public class CMessageDetailsIC : HlaInteractionClass
  {
    #region Declarations
    public HlaParameter TimeStamp;
    public HlaParameter Confirmation;
    public HlaParameter Borrowbook;
    public HlaParameter Returnbook;
   
        #endregion //Declarations

        #region Constructor
        public CMessageDetailsIC() : base()
    {
      // Initialize Class Properties
      Name = "HLAinteractionRoot.MessageDetails";
      ClassPS = PSKind.PublishSubscribe;
      
      // Create Parameters
      // TimeStamp
      TimeStamp = new HlaParameter("TimeStamp");
      Parameters.Add(TimeStamp);
      // Confirmation
      Confirmation = new HlaParameter("Confirmation");
      Parameters.Add(Confirmation);
      // Borrowbook
      Borrowbook = new HlaParameter("Borrowbook");
      Parameters.Add(Borrowbook);
      // Returnbook
      Returnbook = new HlaParameter("Returnbook");
      Parameters.Add(Returnbook);
           
        }
    #endregion //Constructor
  }
}
