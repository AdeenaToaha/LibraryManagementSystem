// **************************************************************************************************
//		CUserOC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;


namespace Library_Management_System.Som
{
  public class CUserOC : HlaObjectClass
  {
    #region Declarations
    public HlaAttribute Status;
    public HlaAttribute Bookname;
    public HlaAttribute Username;
    #endregion //Declarations
    
    #region Constructor
    public CUserOC() : base()
    {
      // Initialize Class Properties
      Name = "HLAobjectRoot.User";
      ClassPS = PSKind.PublishSubscribe;
      
      // Create Attributes
      // Status
      Status = new HlaAttribute("Status", PSKind.PublishSubscribe);
      Attributes.Add(Status);
      // Bookname
      Bookname = new HlaAttribute("Bookname", PSKind.PublishSubscribe);
      Attributes.Add(Bookname);
      // Username
      Username = new HlaAttribute("Username", PSKind.PublishSubscribe);
      Attributes.Add(Username);
    }
    #endregion //Constructor
  }
}
