// **************************************************************************************************
//		CAdminOC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;


namespace Library_Management_System.Som
{
  public class CAdminOC : HlaObjectClass
  {
    #region Declarations
    public HlaAttribute BookAvailability;
    public HlaAttribute Bookid;
    public HlaAttribute Bookdetails;
    #endregion //Declarations
    
    #region Constructor
    public CAdminOC() : base()
    {
      // Initialize Class Properties
      Name = "HLAobjectRoot.Admin";
      ClassPS = PSKind.Subscribe;
      
      // Create Attributes
      // BookAvailability
      BookAvailability = new HlaAttribute("BookAvailability", PSKind.Subscribe);
      Attributes.Add(BookAvailability);
      // Bookid
      Bookid = new HlaAttribute("Bookid", PSKind.Subscribe);
      Attributes.Add(Bookid);
      // Bookdetails
      Bookdetails = new HlaAttribute("Bookdetails", PSKind.Subscribe);
      Attributes.Add(Bookdetails);
    }
    #endregion //Constructor
  }
}
