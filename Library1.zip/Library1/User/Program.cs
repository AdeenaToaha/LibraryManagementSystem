﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
//Racon
using Racon;
// Application
using Library_Management_System.Som;

namespace Library_Management_System
{
    // This federate application uses Racon High-Level Methods
    class Program
    {
        // Globals
        static CSimulationManager manager = new CSimulationManager();
        // Local object
        static CUser user = new CUser(); // Current user
        static bool Terminate = false; // exit switch for app
        static bool test = false; // guard for testing for various RTI interface

        static void Main(string[] args)
        {
            // Initialization with High-level Racon Services

            // Program initialization

            // UI initialization
            PrintVersion();
            Thread ConsoleKeyListener = new Thread(new ThreadStart(ProcessKeyboard));
            ConsoleKeyListener.Name = "KeyListener";

            // Racon Initialization
            // Getting the information/debugging messages from RACoN
            manager.federate.StatusMessageChanged += Federate_StatusMessageChanged;
            manager.federate.LogLevel = LogLevel.ALL;

            // Initialization of User Properties
            Console.ForegroundColor = ConsoleColor.Gray;
            setUserConfiguration(); // get user input
            Console.Title = "CUserFd: " + user.Username; // set console title
            manager.federate.FederationExecution.FederateName = user.Username; // set federate name
            printConfiguration(); // report to user
            ConsoleKeyListener.Start(); // start keyboard event listener

            // Federation Initialization
            // Connect, create and join to federation execution, declare object model
            bool result = manager.federate.InitializeFederation(manager.federate.FederationExecution);

            // Main Simulation Loop - loops until ESC is pressed
            do
            {
                // Process RTI events (callbacks) and tick
                if (manager.federate.FederateState.HasFlag(FederateStates.JOINED)) manager.federate.Run();

                // Handle user activities
                if (test)
                {
                    // Test code or actions
                    test = false;
                }

            } while (!Terminate && !user.Exit);

            // Shutdown
            // Finalize user interface
            ConsoleKeyListener.Abort();
            // Finalize Federation Execution
            // Remove objects
            manager.timer.Stop(); // stop reporting user activities
            manager.federate.DeleteObjectInstance(manager.UserObjects[0], Tags.deleteRemoveTag);
            // Leave and destroy federation execution
            bool result2 = manager.federate.FinalizeFederation(manager.federate.FederationExecution);

            // Write trace log
            StreamWriter file = new System.IO.StreamWriter(@".\TraceLog.txt");
            file.WriteLine(manager.federate.TraceLog);
            file.Close();

            // Exit message
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        // Process Keyboard events
        private static void ProcessKeyboard()
        {
            do
            {
                switch (Console.ReadKey(true).Key)
                {
                    // ... other cases ...

                    case ConsoleKey.Escape:
                        Terminate = true;
                        if (manager.federate is CUserFd)
                        {
                            (manager.federate as CUserFd).Exit = true; // Set Exit property on CUserFd instance
                        }
                        break;
                }
            } while (true);
        }

        // Racon Information received
        private static void Federate_StatusMessageChanged(object sender, EventArgs e)
        {
            Console.ResetColor();
            Console.WriteLine((sender as CUserFd).StatusMessage);
        }

        // Set user configuration
        private static void setUserConfiguration()
        {
            // User configuration logic
            // ...

            // Example default settings
            user.Username = "User-" + DateTime.Now.Second.ToString();
            user.Status = 0;
            user.Exit = false;
            user.Bookname = "Distributed_Simulation1";

            // Encapsulate own user and add to list
            CUserHlaObject encapsulatedUserObject = new CUserHlaObject(manager.federate.Som.UserOC);
            encapsulatedUserObject.User = user;
            manager.UserObjects.Add(encapsulatedUserObject);
        }

        // Print user configuration
        private static void printConfiguration()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nUser configuration:");
            Console.WriteLine("Username: {0}", user.Username);
            // Additional user details
        }

        // Print status
        private static void printStatus()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("*************** Status ***************");
            // Status printing logic
            // ...
            Console.WriteLine("**************************************");
        }

        private static void PrintVersion()
        {
            Console.WriteLine(
                "***************************************************************************\n"
                + "                        " + "CUserFd v1.0.0" + "\n"
                + "***************************************************************************");
        }

    }
}
