// **************************************************************************************************
//		CSimulationManager
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The Simulation Manager manages the (multiple) federation execution(s) and the (multiple instances of) joined federate(s).
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
using System.Timers;

// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;
using System.ComponentModel;

namespace Library_Management_System
{
  public class CSimulationManager
  {
        #region Declarations
        // Communication layer related structures
        public CUserFd federate; // Application-specific federate

        // Local data structures and the computational models
        public BindingList<CUserHlaObject> UserObjects; // Keeps the users in the environment
        public BindingList<CAdminHlaObject> AdminObjects; // Keeps the admins in the environment
        public System.Timers.Timer timer = new System.Timers.Timer(5000); // Timer to report activity periodically
       // public MessageDetails MessageDetails = new MessageDetails();
        #endregion //Declarations

        #region Constructor
        public CSimulationManager()
        {
            // Initialize class elements
            timer.Elapsed += TimerElapsed;

            // Initialize the application-specific federate
            federate = new CUserFd(this);
            // Initialize the federation execution
            federate.FederationExecution.Name = "LibrarySimulation";
            federate.FederationExecution.FederateType = "UserFd";
            federate.FederationExecution.ConnectionSettings = "rti://127.0.0.1";

            // Time management
            federate.Lookahead = 1;

            // Handle RTI type variation
            initialize();

            // Populate the local user list
            UserObjects = new BindingList<CUserHlaObject>();
            AdminObjects = new BindingList<CAdminHlaObject>();
        }
        #endregion //Constructor

        #region Methods
        // Handles naming variation according to HLA specification
        private void initialize()
        {
            switch (federate.RTILibrary)
            {
                case RTILibraryType.HLA13_DMSO:
                case RTILibraryType.HLA13_Portico:
                case RTILibraryType.HLA13_OpenRti:
                    federate.Som.UserOC.Name = "ObjectRoot.User";
                    federate.Som.UserOC.PrivilegeToDelete.Name = "privilegeToDelete";
                    federate.Som.AdminOC.Name = "ObjectRoot.Admin";
                    federate.Som.AdminOC.PrivilegeToDelete.Name = "privilegeToDelete";
                    federate.Som.MessageDetailsIC.Name = "InteractionRoot.MessageDetails";
                    federate.FederationExecution.FDD = @".\LibrarySimFom.fed";
                    break;
                case RTILibraryType.HLA1516e_Portico:
                case RTILibraryType.HLA1516e_OpenRti:
                    federate.Som.UserOC.Name = "HLAobjectRoot.User";
                    federate.Som.UserOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                    federate.Som.AdminOC.Name = "HLAobjectRoot.Admin";
                    federate.Som.AdminOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                    federate.Som.MessageDetailsIC.Name = "HLAinteractionRoot.MessageDetails";
                    federate.FederationExecution.FDD = @".\Library_Management_system.xml";
                    break;
            }
        }
        // Update User Activity
        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            if (UserObjects.Count > 0)
            {
                federate.UpdateActivity(UserObjects[0]); // Ensure this method is defined in CUserFd
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine($"{UserObjects[0].User.Username}: Activity report");
            }

            GC.Collect(); // Consider if necessary
        }
        #endregion //Methods
    }
}
