﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;

namespace Library_Management_System
{
    // Local Domain Object representing a User in the Library Management System
    public class CUser
    {
        public string Username; // Unique identifier for the user
        public string Bookname; // Name of the book currently borrowed or interacted with
        public UserStatus Status; // Current status of the user (e.g., borrowing, returning)
        public bool Exit = false; // is ship exited the strait?

        public CUser()
        {
            Username = "";
            Bookname = "";
            Status = UserStatus.None; // Initial status set to none
        }

        // Additional methods and properties relevant to the user can be added here
    }

    // Enum for user status
    public enum UserStatus
    {
        None, // No current book interaction
        Borrowing, // User is borrowing a book
        Returning // User is returning a book
    }
}
