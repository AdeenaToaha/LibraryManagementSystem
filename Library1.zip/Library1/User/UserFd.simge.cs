// **************************************************************************************************
//		CUserFd
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The application specific federate that is extended from the Generic Federate Class of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;

namespace Library_Management_System
{
  public partial class CUserFd : Racon.CGenericFederate
  {
    #region Declarations
    public Library_Management_System.Som.FederateSom Som;
    #endregion //Declarations
    
    #region Constructor
    public CUserFd() : base(RTILibraryType.HLA1516e_OpenRti)
    {
      // Create and Attach Som to federate
      Som = new Library_Management_System.Som.FederateSom();
      SetSom(Som);
    }
    #endregion //Constructor
    
    #region Event Handlers
    #region Federate Callback Event Handlers

    #endregion //Federate Callback Event Handlers
    #endregion //Event Handlers
  }
}
