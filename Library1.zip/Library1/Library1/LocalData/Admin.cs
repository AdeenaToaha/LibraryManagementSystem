﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Racon
using Racon;
using Racon.RtiLayer;
// App
using Library_Management_System.Som;

namespace Library_Management_System
{
    // Local Domain Object for Admin
    public class CAdmin
    {
        public bool BookAvailability;
        public string BookDetails;
        public int BookId;

        public CAdmin()
        {
            // Initialize default values
            BookAvailability = false;
            BookDetails = "No details available";
            BookId = 0;
        }

        // Additional Computational Model methods can be added here as needed
    }

}
