// **************************************************************************************************
//		CSimulationManager
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The Simulation Manager manages the (multiple) federation execution(s) and the (multiple instances of) joined federate(s).
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;

namespace Library_Management_System
{
  public class CSimulationManager
  {
    #region Declarations
    // Communication layer related structures
    public CAdminFd federate; //Application-specific federate 
    // Local data structures
    // TODO: user-defined data structures are declared here
    #endregion //Declarations
    
    #region Constructor
    public CSimulationManager()
    {
      // Initialize the application-specific federate
      federate = new CAdminFd(this);
      // Initialize the federation execution
      federate.FederationExecution.Name = "LibrarySimulation";
      federate.FederationExecution.FederateType = "AdminFd";
      federate.FederationExecution.ConnectionSettings = "rti://127.0.0.1";
      // Handle RTI type variation
      initialize();
    }
    #endregion //Constructor
    
    #region Methods
    // Handles naming variation according to HLA specification
    private void initialize()
    {
      switch (federate.RTILibrary)
      {
        case RTILibraryType.HLA13_DMSO: case RTILibraryType.HLA13_Portico: case RTILibraryType.HLA13_OpenRti:
                federate.Som.AdminOC.Name = "objectRoot.Admin";
                federate.Som.AdminOC.PrivilegeToDelete.Name = "privilegeToDelete";
                federate.Som.UserOC.Name = "objectRoot.User";
                federate.Som.UserOC.PrivilegeToDelete.Name = "privilegeToDelete";
                federate.Som.MessageDetailsIC.Name = "interactionRoot.MessageDetails";
                federate.FederationExecution.FDD = @".\Library_Management_system.fed";
        break;
        case RTILibraryType.HLA1516e_Portico: case RTILibraryType.HLA1516e_OpenRti:
                federate.Som.AdminOC.Name = "HLAobjectRoot.Admin";
                federate.Som.AdminOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                federate.Som.UserOC.Name = "HLAobjectRoot.User";
                federate.Som.UserOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                federate.Som.MessageDetailsIC.Name = "HLAinteractionRoot.MessageDetails";
                federate.FederationExecution.FDD = @".\Library_Management_system.xml";
        break;
      }
    }
    #endregion //Methods
  }
}
