// **************************************************************************************************
//		CAdminOC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;


namespace Library_Management_System.Som
{
  public class CAdminOC : HlaObjectClass
  {
    #region Declarations
    public HlaAttribute BookAvailability;
    public HlaAttribute Bookdetails;
    public HlaAttribute Bookid;
    #endregion //Declarations
    
    #region Constructor
    public CAdminOC() : base()
    {
      // Initialize Class Properties
      Name = "HLAobjectRoot.Admin";
      ClassPS = PSKind.PublishSubscribe;
      
      // Create Attributes
      // BookAvailability
      BookAvailability = new HlaAttribute("BookAvailability", PSKind.PublishSubscribe);
      Attributes.Add(BookAvailability);
      // Bookdetails
      Bookdetails = new HlaAttribute("Bookdetails", PSKind.PublishSubscribe);
      Attributes.Add(Bookdetails);
      // Bookid
      Bookid = new HlaAttribute("Bookid", PSKind.PublishSubscribe);
      Attributes.Add(Bookid);
    }
    #endregion //Constructor
  }
}
