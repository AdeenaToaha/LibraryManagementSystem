// **************************************************************************************************
//		FederateSom
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	03 January 2024 1:16:55 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using Library_Management_System.Som;


namespace Library_Management_System.Som
{
  public class FederateSom : Racon.ObjectModel.CObjectModel
  {
    #region Declarations
    #region SOM Declaration
    public Library_Management_System.Som.CAdminOC AdminOC;
    public Library_Management_System.Som.CUserOC UserOC;
    public Library_Management_System.Som.CMessageDetailsIC MessageDetailsIC;
    #endregion
    #endregion //Declarations
    
    #region Constructor
    public FederateSom() : base()
    {
      // Construct SOM
      AdminOC = new Library_Management_System.Som.CAdminOC();
      AddToObjectModel(AdminOC);
      UserOC = new Library_Management_System.Som.CUserOC();
      AddToObjectModel(UserOC);
      MessageDetailsIC = new Library_Management_System.Som.CMessageDetailsIC();
      AddToObjectModel(MessageDetailsIC);
    }
    #endregion //Constructor
  }
}
