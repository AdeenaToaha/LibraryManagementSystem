﻿using System;
using System.Threading;
// Racon
using Racon;
// Application
using Library_Management_System.Som;

namespace Library_Management_System
{
    public class Program
    {
        static bool Terminate = false; // Exit switch for the app
        static public CAdminFd federate; // Application-specific federate 

        static void Main(string[] args)
        {
            // Initialization with Low-level Racon Services
            CSimulationManager simulationManager = new CSimulationManager(); // Placeholder for your CSimulationManager
            //federate = new CAdminFd(simulationManager); // Initialize the application-specific federate

            // UI initialization
            PrintVersion();
            Thread ConsoleKeyListener = new Thread(new ThreadStart(ProcessKeyboard));
            ConsoleKeyListener.Name = "KeyListener";

            // Racon Initialization
            simulationManager.federate.StatusMessageChanged += Federate_StatusMessageChanged;
            simulationManager.federate.LogLevel = LogLevel.ALL;

            // Console Initialization
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Title = "AdminFd";

            ConsoleKeyListener.Start(); // Start keyboard event listener

            // RTI Initialization (Placeholder for your RTI setup)
            // Example: federate.Connect, federate.JoinFederationExecution, etc.
            // Federation Initialization
            // Connect, create and join to federation execution, declare object model
            bool result = simulationManager.federate.InitializeFederation(simulationManager.federate.FederationExecution);

            // Main Simulation Loop
            do
            {
                // Process RTI events (callbacks) and tick
                if (simulationManager.federate.FederateState.HasFlag(FederateStates.JOINED))
                    simulationManager.federate.Run();

                // Add more logic here as needed

            } while (!Terminate);

            // Shutdown
            ConsoleKeyListener.Abort();
            // Placeholder for your federate shutdown logic
            // Example: federate.Disconnect, federate.LeaveFederationExecution, etc.

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        private static void ProcessKeyboard()
        {
            do
            {
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.Escape:
                        Terminate = true;
                        break;
                        // Add more key handling logic here as needed
                }
            } while (true);
        }

        private static void Federate_StatusMessageChanged(object sender, EventArgs e)
        {
            Console.ResetColor();
            Console.WriteLine((sender as CAdminFd).StatusMessage);
        }

        private static void PrintVersion()
        {
            Console.WriteLine(
                "***************************************************************************\n"
                + "                        " + "AdminFd v1.0.0" + "\n"
                + "***************************************************************************");
        }
    }
}
